<?php

namespace App\BCM;

use Illuminate\Database\Eloquent\Model;

class Unik extends Model
{
  protected $table = 'bcm_unik';
  protected $primaryKey = 'akses';
  public $timestamps = false;

}
