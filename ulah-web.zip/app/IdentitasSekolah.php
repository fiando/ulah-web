<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdentitasSekolah extends Model
{
  protected $table = 'identitas_sekolah';
  protected $primaryKey = 'ididentitas_sekolah';
  public $timestamps = false;
}
