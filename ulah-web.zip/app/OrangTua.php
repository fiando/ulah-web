<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrangTua extends Model
{
  protected $table = 'orang_tua';
  protected $primaryKey = 'idorang_tua';
  public $timestamps = false;
}
