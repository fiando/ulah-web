<footer class="footer">
  <div class="container-fluid">
    <nav class="pull-left">
      <ul>
        <li>
          <a href="{{url("tentang-aplikasi")}}">
            Tentang Aplikasi
          </a>
        </li>
      </ul>
    </nav>
    <p class="copyright pull-right">
      &copy; <script>document.write(new Date().getFullYear())</script> ULah & Template by <a href="https://www.creative-tim.com/product/light-bootstrap-dashboard">Creative Tim</a>
    </p>
  </div>
</footer>
