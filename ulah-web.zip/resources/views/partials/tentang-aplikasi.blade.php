<div class="container-fluid">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="card">
        <div class="header text-center">
          <h4 class="title">ULAH - Pembayaran Uang Sekolah Online</h4>
          <p class="category">Cara bayar Uang Sekolah Praktis & Modern</p>
          <br>
        </div>
        <div class="content text-center">
          <div class="row">
            <div class="col-md-6 col-md-offset-3">
              <img class="img-responsive" src="{{url("img/logo.png")}}" alt="Logo ULAH">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
