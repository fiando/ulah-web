@extends($level . '/master')

@section('title','Tentang Aplikasi')

@section('content')
  @include('partials.tentang-aplikasi')
@endsection
