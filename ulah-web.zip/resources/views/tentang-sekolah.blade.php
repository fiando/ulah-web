@extends($level . '/master')

@section('title','Tentang Sekolah')

@section('content')
  @include('partials.tentang-sekolah')
@endsection
