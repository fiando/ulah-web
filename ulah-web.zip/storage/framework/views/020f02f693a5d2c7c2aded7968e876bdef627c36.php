<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('desc','Manajemen Tagihan & Pembayaran Online'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="content">
          <h4 class="title">Tahun Ajaran : <small>2017/2018</small></h4>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Tagihan</h4>
        </div>
        <div class="content">
          <p>Ada 5 Tagihan Siswa Belum Terbayar</p>
          <a href="#" class="btn btn-primary btn-block">Periksa Semua Tagihan</a>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Transaksi Pembayaran Terbaru</h4>
        </div>
        <div class="content">
          <ul class="list-unstyled">
            <li><b>10-01-2018 </b>NIS - <i>Pembayaran SPP</i> - Rp.250.000<li>
            <li><b>10-01-2018 </b>NIS - <i>Pembayaran SPP</i> - Rp.250.000<li>
            <li><b>10-01-2018 </b>NIS - <i>Pembayaran SPP</i> - Rp.250.000<li>
          </ul>
          <a href="#" class="btn btn-info btn-block">Periksa Semua Pembayaran</a>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Profil Sekolah</h4>
        </div>
        <div class="content">
          <dl class="dl-horizontal">
            <dt>ID Sekolah :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Nama Sekolah :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Status Sekolah :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Bentuk Pendidikan :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Akreditasi :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Kurikulum :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Kepala Sekolah : </dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Alamat :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Email :</dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>No. Telepon : </dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Rekening : </dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
            <dt>Website : </dt>
            <dd>Lorem ipsum dolor sit amet.</dd>
          </dl>
          <a href="#" class="btn btn-default btn-block">Update Profil Sekolah</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>