<?php $__env->startSection('title','Tentang Sekolah'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('partials.tentang-sekolah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($level . '/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>