<?php $__env->startSection('title','Detail User'); ?>
<?php $__env->startSection('desc','Melihat Detail Data User'); ?>

<?php $__env->startSection('content'); ?>
  <?php if($user->level == 'admin'): ?>
    <div class="col-md-6 col-md-offset-3">
    <?php else: ?>
      <div class="col-md-6">
  <?php endif; ?>
  <div class="card">
    <div class="header">
      <h4 class="title">Info User</h4>
    </div>
  <div class="content">
    <h5><p class="category">ID</p><?php echo e($user->idusers); ?></h5>
    <h5><p class="category">Nama</p><?php echo e($user->nama); ?></h5>
    <h5><p class="category">Email</p><?php echo e($user->email); ?></h5>
    <h5><p class="category">Username</p><?php echo e($user->username); ?></h5>
    <h5><p class="category">No. Telp</p><?php echo e($user->no_telp); ?></h5>
    <h5><p class="category">Alamat</p><?php echo e($user->alamat); ?></h5>
    <h5><p class="category">Bank</p><?php echo e($user->idbank); ?></h5>
    <h5><p class="category">No. Rekening</p><?php echo e($user->no_rekening); ?></h5>
    <h5><p class="category">Level</p><?php echo e(user_level($user->level)); ?></h5>
    <h5><p class="category">Status</p><?php echo e(user_status($user->status)); ?></h5>

    <form class="" action="<?php echo e(url("admin/user/{$user->idusers}")); ?>" method="post">
      <a class="btn btn-fill btn-info" href="<?php echo e(url("admin/user/{$user->idusers}")); ?>/edit">Edit</a>
      <button class="btn btn-fill btn-danger" type="submit" name="delete" onClick="return confirm('Anda yakin ingin menghapus ?')">Delete</button>
      <?php echo e(method_field('DELETE')); ?>

      <?php echo e(csrf_field()); ?>

    </form>
  </div>
  </div>
</div>
<?php if($user->level != 'admin'): ?>
  <?php echo $__env->make('admin.user.info-siswa',$user, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.user.info-ortu',$user, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>