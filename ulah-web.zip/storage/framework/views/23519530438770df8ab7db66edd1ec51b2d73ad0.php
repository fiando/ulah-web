<?php $__env->startSection('title','Tagihan Siswa'); ?>
<?php $__env->startSection('desc','Informasi Tagihan Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8">
      <form class="" action="<?php echo e(url("siswa/pembayaran_tagihan")); ?>" method="post">
        <div class="card">
          <div class="content">
            <div class="form-check">
              <label class="form-check-label">
                <input class="form-check-input" type="checkbox" value="">
                <span class="form-check-sign"></span>
                Pilih Semua
              </label>
            </div>
            <ul class="list-group">
              <li class="list-group-item">
                <div class="row">
                  <div class="col-xs-12">
                    <div class="text-header">
                      <input type="checkbox" class="" name="tagihan" value="">
                      <b class="text-left">Pembayaran SPP</b>
                      <b class="text-left pull-right"><i>01 Januari 2018</i></b>
                    </div>
                    <div class="col-xs-12">
                      Nominal : Rp 250.000
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <div class="form-group">
              <h4>Total Tagihan : <small>Rp. 425.000 ( 3 Tagihan )</small></h4>
                <button type="submit" class="btn btn-primary btn-block btn-fill">LUNASI YANG DIPILIH</button>
            </div>
          </div>
        </div>
        <?php echo e(csrf_field()); ?>

      </form>
    </div>
    <div class="col-md-4">
      <div class="well">
        <div class="header">
          <h4 class="title">Filter</h4>
        </div>
        <div class="content">
          <form class="form-horizontal">
            <div class="form-group">
              <label class="col-sm-4 control-label">Tahun Ajaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="tahun_ajaran">
                  <option value="">Semua</option>
                  <option value="">2017/2018</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-4 control-label">Jenis Pembayaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="jenis_pembayaran">
                  <option value="">Semua</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-4 col-sm-8">
                <button type="submit" class="btn btn-info btn-block btn-fill">Filter</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>