<?php $__env->startSection('title','Tambah Tahun Ajaran'); ?>
<?php $__env->startSection('desc','Menambahkan Data Tahun Ajaran'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <?php if($message = Session::get('success')): ?>
           <div class="alert alert-success">
               <p><?php echo e($message); ?></p>
           </div>
       <?php endif; ?>
      <div class="card">
        <div class="content">
          <form class="" action="<?php echo e(url("admin/tahun-ajaran")); ?>" method="post">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Tahun Ajaran</label>
                <input type="text" class="form-control" placeholder="Tahun Ajaran" name="tahun_pelajaran" value="<?php echo e(Request::input("tahun_pelajaran")); ?>">
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-success btn-fill pull-right">Tambah Tahun Ajaran</button>
          <div class="clearfix"></div>
          <?php echo e(csrf_field()); ?>

        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>