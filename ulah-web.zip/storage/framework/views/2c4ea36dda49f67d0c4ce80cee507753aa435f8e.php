<?php $__env->startSection('title','Edit Bank'); ?>
<?php $__env->startSection('desc','Mengedit Data Bank'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <?php if($message = Session::get('success')): ?>
           <div class="alert alert-success">
               <p><?php echo e($message); ?></p>
           </div>
       <?php endif; ?>
      <div class="card">
        <div class="header">
          <h4 class="title">Edit Bank
            <a href="<?php echo e(url("admin/bank")); ?>" class="btn btn-warning btn-fill btn-sm">Kembali</a>
          </h4>
        </div>
        <div class="content">
          <form action="<?php echo e(url("admin/bank/{$bank->kode}")); ?>" method="post">
            <?php echo e(method_field('PUT')); ?>

            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Kode Bank</label>
                  <input type="text" class="form-control" placeholder="Kode Bank" name="kode" value="<?php echo e($bank->kode); ?>">
                </div>
                <div class="form-group">
                  <label>Bank</label>
                  <input type="text" class="form-control" placeholder="Bank" name="nama" value="<?php echo e($bank->nama); ?>">
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-info btn-fill pull-right">Update Bank</button>
            <div class="clearfix"></div>
            <?php echo e(csrf_field()); ?>

          </form>
          <div class="clearfix"></div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>