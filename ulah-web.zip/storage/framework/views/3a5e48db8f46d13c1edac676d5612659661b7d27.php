<?php $__env->startSection('title','Tagihan Siswa'); ?>
<?php $__env->startSection('desc','Informasi Tagihan Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-6 col-md-offset-1">
        <div class="card">
          <div class="content">

        <ul class="list-group">
          <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
              <b class="text-left"><?php echo e($v->nama_pembayaran); ?></b>
              <b class="text-left">[ <i><?php echo e(date("d-m-Y", strtotime($v->tgl_tagihan))); ?></i> ]</b>
              <br>
              Nominal : Rp<?php echo e(number_format($v->nominal,0,0,'.')); ?><br />
              <?php if($siswa->akses_pembayaran or session('level') == 'orang_tua'): ?>
                <?php if(isset($v->ref)): ?>
                  <form class="" action="<?php echo e(url("refresh_tagihan")); ?>" method="post">
                    <a href="<?php echo e(url('pembayaran_tagihan/cek')); ?>?id_tagihan=<?php echo e($v->idpembayaran); ?>" class="btn btn-info btn-fill btn-sm">Periksa</a>
                    <button type="submit" name="notif" class="btn btn-sm btn-success btn-fill">Refresh</button><br>
                    <input type="hidden" name="id_tagihan" value="<?php echo e($v->idpembayaran); ?>">
                    <?php echo e(csrf_field()); ?>

                  </form>
                  <?php else: ?>
                  <a href="<?php echo e(url('pembayaran_tagihan/')); ?>?id_tagihan=<?php echo e($v->idpembayaran); ?>" class="btn btn-primary btn-fill btn-sm" target="_blank">Bayar</a>
                <?php endif; ?>
              <?php endif; ?>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="form-group">
          <h4>Total Tagihan : <small>Rp<?php echo e(number_format($total_transaksi,0,0,'.')); ?> ( <?php echo e($tagihan_count); ?> Tagihan )</small></h4>
          
        </div>
        
      </div>
    </div>
</div>
<div class="col-md-4">
  <div class="well">
    <div class="header">
      <h4 class="title">Filter</h4>
    </div>
    <div class="content">
      <form class="form-horizontal">
        <div class="form-group">
          <label class="col-sm-4 control-label">Tahun Ajaran</label>
          <div class="col-sm-8">
            <select class="form-control" name="tahun_ajaran">
              <option value="">Semua</option>
              <option value="">2017/2018</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-sm-4 control-label">Jenis Pembayaran</label>
          <div class="col-sm-8">
            <select class="form-control" name="jenis_pembayaran">
              <option value="">Semua</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-4 col-sm-8">
            <button type="button" class="disabled btn btn-info btn-block btn-fill">Filter</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>