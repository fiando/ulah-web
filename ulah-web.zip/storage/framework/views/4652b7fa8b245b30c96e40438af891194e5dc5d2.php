<?php $__env->startSection('title','Detail Jenis Pembayaran'); ?>
<?php $__env->startSection('desc','Melihat Detail Data Jenis Pembayaran'); ?>

<?php $__env->startSection('content'); ?>


  <div class="card">
  <div class="content">
    <h5><p class="category">ID</p><?php echo e($jenis_pembayaran->idjenis_pembayaran); ?></h5>
    <h5><p class="category">Jenis Pembayaran</p><?php echo e($jenis_pembayaran->nama_pembayaran); ?></h5>
    <h5><p class="category">Nominal</p><?php echo e($jenis_pembayaran->nominal); ?></h5>

    <form class="" action="<?php echo e(url("admin/jenis-pembayaran/{$jenis_pembayaran->idjenis_pembayaran}")); ?>" method="post">
      <a class="btn btn-fill btn-info" href="<?php echo e(url("admin/jenis-pembayaran/{$jenis_pembayaran->idjenis_pembayaran}")); ?>/edit">Edit</a>
      <button class="btn btn-fill btn-danger" type="submit" name="delete" onClick="return confirm('Anda yakin ingin menghapus ?')">Delete</button>
      <?php echo e(method_field('DELETE')); ?>

      <?php echo e(csrf_field()); ?>

    </form>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>