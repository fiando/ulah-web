<?php $__env->startSection('title','Siswa'); ?>
<?php $__env->startSection('desc','Manajemen Siswa'); ?>

<?php $__env->startSection('content'); ?>

  <div class="col-md-12">
    <a class="btn btn-success btn-fill" href="<?php echo e(url("admin/siswa/create")); ?>">Tambah Siswa</a>
  </div>

  <div class="col-md-12">
    <div class="card card-plain">
      <div class="content table-responsive table-full-width">
        <table id="siswa-table" class="table display" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nama</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
          </tfoot>
          <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($value['idusers']); ?></td>
                <td><?php echo e($value['nama']); ?></td>
                <td><?php echo e($value['email']); ?></td>
                <td><?php echo e(user_status($value['status'])); ?></td>
                <td width="20%">
                  <form class="" action="<?php echo e(url("admin/siswa/{$value['idusers']}")); ?>" method="post">
                  <a class="btn btn-sm btn-fill btn-primary" href="<?php echo e(url("admin/siswa/{$value['idusers']}")); ?>">View</a>
                  <a class="btn btn-sm btn-fill btn-info" href="<?php echo e(url("admin/siswa/{$value['idusers']}/edit")); ?>">Edit</a>
                    <button class="btn btn-sm btn-fill btn-danger" type="submit" name="delete" onClick="return confirm('Anda yakin ingin menghapus ?')">Delete</button>
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('script'); ?>
    ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
    <script type="text/javascript">
    $(document).ready( function () {
      $('#siswa-table').DataTable( {
        "order": [[ 0, "desc" ]]
    });
    } );
    </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>