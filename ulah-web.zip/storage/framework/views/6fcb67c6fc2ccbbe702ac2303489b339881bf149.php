<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="icon" type="image/png" href="<?php echo e(url("img/logo.png")); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

  <title>ULah - <?php echo $__env->yieldContent('title'); ?></title>

  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
  <meta name="viewport" content="width=device-width" />


  <!-- Bootstrap core CSS     -->
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />

  <!-- Animation library for notifications   -->
  <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet"/>

  <!--  Light Bootstrap Table core CSS    -->
  <link href="<?php echo e(asset('css/light-bootstrap-dashboard.css?v=1.4.0')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('lib/DataTables/datatables.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"/>

  <!--     Fonts and icons     -->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
  <link href="<?php echo e(asset('css/pe-icon-7-stroke.css')); ?>" rel="stylesheet" />

</head>
<body>

  <div class="wrapper">
    <?php echo $__env->make('admin.partials.sidebar', [], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main-panel">
      <?php echo $__env->make('admin.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="content">
        <div class="container-fluid">
          <?php if(isset($_SESSION['msg_info'])): ?>
            <div class="alert alert-info">
              <span><?php echo e($msg_info); ?></span>
            </div>
          <?php endif; ?>
          <?php if (! empty(trim($__env->yieldContent('title')))): ?>
            <?php if (! empty(trim($__env->yieldContent('desc')))): ?>
              <div class="card">
                <div class="header">
                  <h4 class="title"><?php echo $__env->yieldContent('title'); ?></h4>
                  <p class="category"><?php echo $__env->yieldContent('desc'); ?></p>
                  <br>
                </div>
              </div>
            <?php endif; ?>
          <?php endif; ?>
          <?php $__env->startSection('content'); ?>
            content
          <?php echo $__env->yieldSection(); ?>
        </div>
      </div>
      <?php echo $__env->make('admin.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</body>

<?php $__env->startSection('script'); ?>
  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('js/jquery.3.2.1.min.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>

  <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
  <script src="<?php echo e(asset('js/light-bootstrap-dashboard.js?v=1.4.0')); ?>"></script>
  <script src="<?php echo e(asset('lib/DataTables/datatables.min.js')); ?>"></script>
<?php echo $__env->yieldSection(); ?>

</html>
