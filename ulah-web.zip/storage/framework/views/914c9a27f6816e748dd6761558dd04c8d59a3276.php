<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('desc','Cek Tagihan & Pembayaran Online'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Tagihan</h4>
        </div>
        <div class="content">
          <p><b>Total : </b>Rp<?php echo e(number_format($total_tagihan,0,0,'.')); ?> ( <?php echo e($tagihan_count); ?> Tagihan )</p>
          <ul class="list-group">
            <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item">
                <div class="text-header">
                  <b class="text-left"><?php echo e($v->nama_pembayaran); ?></b>
                  <b class="text-right pull-right"><?php echo e(date("d-m-Y", strtotime($v->tgl_tagihan))); ?></b>
                </div>
                Nominal : Rp<?php echo e(number_format($v->nominal,0,0,'.')); ?>

              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <a href="<?php echo e(url("siswa/tagihan")); ?>" class="btn btn-primary btn-block">Periksa Semua Tagihan</a>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Pembayaran</h4>
        </div>
        <div class="content">
          <h5><b>Total Transaksi</b></h5>
          <p>Rp<?php echo e(number_format($total_transaksi,0,'','.')); ?></p>
          <h5><b>Banyaknya Transaksi</b></h5>
          <p><?php echo e($pembayaran_count); ?> Kali</p>
          <a href="<?php echo e(url("siswa/pembayaran")); ?>" class="btn btn-primary btn-block">Lihat Semua Pembayaran</a>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Profil Orang Tua</h4>
        </div>
        <div class="content">
          <dl class="dl-horizontal">
            <dt>Nama :</dt>
            <dd><?php echo e($siswa->nama); ?></dd>
            <dt>Alamat :</dt>
            <dd><?php echo e($siswa->alamat); ?></dd>
            <dt>No. Telp :</dt>
            <dd><?php echo e($siswa->no_telp); ?></dd>
            <dt>Email :</dt>
            <dd><?php echo e($siswa->email); ?></dd>
            <dt>Username :</dt>
            <dd><?php echo e($siswa->username); ?></dd>
            <dt>Nama Bank :</dt>
            <dd><?php echo e($siswa->nama_bank); ?></dd>
            <dt>No. Rekening :</dt>
            <dd><?php echo e($siswa->no_rekening); ?></dd>
          </dl>
          <a href="<?php echo e(url("siswa/akun")); ?>" class="btn btn-primary btn-block">Update Profil</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('orang-tua/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>