<?php $__env->startSection('title','Tambah Jenis Pembayaran'); ?>
<?php $__env->startSection('desc','Menambahkan Data Jenis Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <?php if($message = Session::get('success')): ?>
           <div class="alert alert-success">
               <p><?php echo e($message); ?></p>
           </div>
       <?php endif; ?>
      <div class="card">
        <div class="content">
          <form class="" action="<?php echo e(url("admin/jenis-pembayaran")); ?>" method="post">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Jenis Pembayaran</label>
                <input type="text" class="form-control" placeholder="Jenis Pembayaran" name="jenis_pembayaran" value="<?php echo e(Request::input("jenis_pembayaran")); ?>">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Nominal</label>
                <input type="text" class="form-control" placeholder="Nominal" name="nominal" value="<?php echo e(Request::input("nominal")); ?>">
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-success btn-fill pull-right">Tambah Jenis Pembayaran</button>
          <div class="clearfix"></div>
          <?php echo e(csrf_field()); ?>

        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>