<?php $__env->startSection('title','Periksa Tagihan Siswa'); ?>
<?php $__env->startSection('desc','Informasi Tagihan Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="card">
        <div class="content">
          <div class="form-group">
            <h4 class="text-left">Tagihan Tanggal <b><i><?php echo e(date("d-m-Y", strtotime($tagihan->tgl_tagihan))); ?></i></b></h4>
            <h4 class="text-left">Pembayaran <b><?php echo e($tagihan->nama_pembayaran); ?></b></h4>
            <h4>Nominal : <b>Rp<?php echo e(number_format($tagihan->nominal,0,0,'.')); ?></b></h4>
            <h4>Metode Pembayaran : <b><?php echo e(($tagihan->method == 'trf') ? 'Transfer' : 'Credit Card'); ?></b></h4>
            <h4>Status : <b><?php echo e($status->text); ?></b></h4>
            <a href="<?php echo e(url('tagihan')); ?>" class="btn btn-primary btn-fill btn-block">Kembali</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>