<?php $__env->startSection('title','Tambah Tagihan'); ?>
<?php $__env->startSection('desc','Menambahkan Data Tagihan'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <?php if($message = Session::get('success')): ?>
           <div class="alert alert-success">
               <p><?php echo e($message); ?></p>
           </div>
       <?php endif; ?>
      <div class="card">
        <div class="content">
          <form class="" action="<?php echo e(url("admin/tagihan")); ?>" method="post">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>NIS</label>
                <select class="form-control" name="nis">
                  <?php $__currentLoopData = $nis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->nis); ?>"><?php echo e($v->nama); ?> ( <?php echo e($v->nis); ?> )</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label>Tagihan</label>
                <input type="date" class="form-control" placeholder="Tagihan" name="tagihan" value="<?php echo e(Request::input("tagihan")); ?>">
              </div>
              <div class="form-group">
                <label>Jenis Pembayaran</label>
                <select class="form-control" name="jenis_pembayaran">
                  <?php $__currentLoopData = $jenis_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->idjenis_pembayaran); ?>"><?php echo e($v->nama_pembayaran); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label>Tahun Pelajaran</label>
                <select class="form-control" name="tahun_pelajaran">
                  <?php $__currentLoopData = $tahun_pelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v->idtahun_pelajaran); ?>"><?php echo e($v->tahun_pelajaran); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-success btn-fill pull-right">Tambah Tagihan</button>
          <div class="clearfix"></div>
          <?php echo e(csrf_field()); ?>

        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>