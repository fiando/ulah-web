<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('desc','Cek Tagihan & Pembayaran Online'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Tagihan</h4>
        </div>
        <div class="content">
          <p><b>Total : </b>Rp. 425.000 ( 3 Tagihan )</p>
          <ul class="list-group">
            <li class="list-group-item">
              <div class="text-header">
                <b class="text-left">Pembayaran SPP</b>
                <b class="text-right pull-right">01 Januari 2018</b>
              </div>
              Nominal : Rp 250.000
            </li>
            <li class="list-group-item">
              <div class="text-header">
                <b class="text-left">Pembayaran SPP</b>
                <b class="text-right pull-right">01 Januari 2018</b>
              </div>
              Nominal : Rp 250.000
            </li>
            <li class="list-group-item">
              <div class="text-header">
                <b class="text-left">Pembayaran SPP</b>
                <b class="text-right pull-right">01 Januari 2018</b>
              </div>
              Nominal : Rp 250.000
            </li>
          </ul>
          <a href="#" class="btn btn-primary btn-block">Periksa Semua Tagihan</a>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Pembayaran</h4>
        </div>
        <div class="content">
          <p><b>Total Pembayaran Bulan ini : </b>Rp. 425.000 ( 1 x Transaksi )</p>
          <p><b>Histori Pembayaran : </b>Rp. 1.125.000</p>
          <p><b>Total Transaksi : </b>5 Kali</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Profil Siswa</h4>
        </div>
        <div class="content">
          <div class="typo-line"><h6><p class="category">Nama</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">Alamat</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">No. Telp</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">Email</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">Username</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">Nama Bank</p>Isi</h6></div>
          <div class="typo-line"><h6><p class="category">No. Rekening</p>Isi</h6></div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>