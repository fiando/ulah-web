<?php $__env->startSection('title','Pembayaran Tagihan Siswa'); ?>
<?php $__env->startSection('desc','Pilih metode pembayaran untuk melakukan pembayaran'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="card">
        <div class="content">
          <ul class="list-group">
            <li class="list-group-item">
              <div class="row">
                <div class="col-xs-12">
                  <div class="text-header">
                    <b class="text-left">Pembayaran SPP</b>
                    <b class="text-left pull-right"><i>01 Januari 2018</i></b>
                  </div>
                  <div class="col-xs-12">
                    Nominal : Rp 250.000
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <div class="form-group">
            <h4>Bayar Tagihan : <small>Rp. 425.000 ( 3 Tagihan )</small></h4>
            <hr>
            <h4>Metode Pembayaran</h4>
            <div class="row">
              <div class="col-md-6">
                <div class="thumbnail">
                  <img src="..." alt="...">
                  <div class="caption">
                    <h3>Tmoney</h3>
                    <p><a href="#" class="btn btn-primary btn-block" role="button">Lanjutkan</a> </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>