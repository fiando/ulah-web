<?php $__env->startSection('title','Identitas Orang Tua'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="card">
          <div class="header text-center">
            <h4 class="title">Profil Orang Tua</h4>
            <p class="category">Identitas Orang Tua</p>
            <br>
          </div>
          <div class="content">
            <div class="row">
              <div class="col-md-8 col-md-offset-2">
                <dl class="dl-horizontal">
                  <dt>Email :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>Username ( KTP ) :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>Nama :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>No. Telepon :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>Alamat :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>Nama Bank :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                  <dt>No. Rekening :</dt>
                  <dd>Lorem ipsum dolor sit amet.</dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>