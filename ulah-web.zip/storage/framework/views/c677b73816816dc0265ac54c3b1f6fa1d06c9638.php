<?php $__env->startSection('title','Tambah Siswa'); ?>
<?php $__env->startSection('desc','Menambahkan Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <form class="" action="<?php echo e(url("admin/siswa")); ?>" method="post">
    <div class="row">
      <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
      </div>
      <div class="col-md-6">
        <div class="card">
          <div class="header">
            <h4 class="title">Data User</h4>
          </div>
          <div class="content">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Nama</label>
                  <input type="text" class="form-control" placeholder="Nama" name="nama" value="<?php echo e(old('nama')); ?>" autofocus="">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label>Username</label>
                  <input type="text" class="form-control" placeholder="Username" name="username_siswa" value="<?php echo e(old('username_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-5">
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" placeholder="Email" name="email_siswa" value="<?php echo e(old('email_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" class="form-control" placeholder="Password" name="password_siswa" value="<?php echo e(old('password_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-4">
                <p>Status Siswa</p>
                <div class="radio">
                  <input type="radio" name="status_siswa" id="aktif" value="aktif" checked>
                  <label for="aktif">
                    Aktif
                  </label>
                </div>
                <div class="radio">
                  <input type="radio" name="status_siswa" id="tidak_aktif" value="nonaktif" >
                  <label for="tidak_aktif">
                    Nonaktif
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="content">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>No. Telp</label>
                  <input type="text" class="form-control" placeholder="No. Telp" name="no_telp_siswa" value="<?php echo e(old('no_telp_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" class="form-control" placeholder="Alamat" name="alamat_siswa" value="<?php echo e(old('no_telp_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label>ID Bank</label>
                  <input type="text" class="form-control" placeholder="ID Bank" name="idbank_siswa" value="<?php echo e(old('idbank_siswa')); ?>">
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label>No Rekening</label>
                  <input type="text" class="form-control" placeholder="No Rekening" name="no_rekening_siswa" value="<?php echo e(old('no_rekening_siswa')); ?>">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card">
          <div class="header">
            <h4 class="title">Data Siswa</h4>
          </div>
          <div class="content">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="tingkat">Tingkat</label>
                  <select class="form-control" id="tingkat" name="idtingkat">
                    <?php $__currentLoopData = $tingkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($v->idtingkat); ?>"><?php echo e($v->nama_tingkat); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="kategori">Kategori</label>
                  <select class="form-control" id="kategori" name="idkategori">
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($v->idkategori); ?>"><?php echo e($v->nama_kategori); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="orang_tua">Orang Tua</label>
                  <select class="form-control" id="orang_tua" name="idorang_tua">
                    <?php $__currentLoopData = $orang_tua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($v->idorang_tua); ?>"><?php echo e($v->idusers); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <br>
                  <a class="btn btn-info btn-fill" data-toggle="collapse" data-target="#data_ortu">Isi Data Orang Tua</a>
                  <br><i>jika tidak memilih, silahkan isi data orang tua </i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="data_ortu" class="collapse">
          <div class="card">
            <div class="header">
              <h4 class="title">Data Orang Tua</h4>
            </div>
            <div class="content">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" placeholder="Nama" name="nama_orang_tua" value="<?php echo e(old('nama_orang_tua')); ?>" autofocus="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" placeholder="Username" name="username_orang_tua" value="<?php echo e(old('username_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" placeholder="Email" name="email_orang_tua" value="<?php echo e(old('email_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" placeholder="Password" name="password_orang_tua" value="<?php echo e(old('password_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-4">
                  <p>Status Orang Tua</p>
                  <div class="radio">
                    <input type="radio" name="status_orang_tua" id="aktif" value="aktif" checked>
                    <label for="aktif">
                      Aktif
                    </label>
                  </div>
                  <div class="radio">
                    <input type="radio" name="status_orang_tua" id="tidak_aktif" value="nonaktif" >
                    <label for="tidak_aktif">
                      Nonaktif
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="content">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>No. Telp</label>
                    <input type="text" class="form-control" placeholder="No. Telp" name="no_telp_orang_tua" value="<?php echo e(old('no_telp_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" class="form-control" placeholder="Alamat" name="alamat_orang_tua" value="<?php echo e(old('alamat_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>ID Bank</label>
                    <input type="text" class="form-control" placeholder="ID Bank" name="idbank_orang_tua" value="<?php echo e(old('idbank_orang_tua')); ?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>No Rekening</label>
                    <input type="text" class="form-control" placeholder="No Rekening" name="no_rekening_orang_tua" value="<?php echo e(old('no_rekening_orang_tua')); ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <button type="submit" class="btn btn-block btn-success btn-fill">Tambah Siswa</button>
        <div class="clearfix"></div>
        <?php echo e(csrf_field()); ?>

      </div>


    </form>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>