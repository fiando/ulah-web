<div class="card">
  <div class="header">
    <h4 class="title">Profil Siswa
      <?php if(session('level') == 'orang_tua'): ?>
        <a href="<?php echo e(url("pilih_siswa")); ?>" class="btn btn-primary btn-sm">Pilh Siswa</a>
      <?php endif; ?>
    </h4>
  </div>
  <div class="content">
    <dl class="dl-horizontal">
      <dt>Nama :</dt>
      <dd><?php echo e($siswa->nama); ?></dd>
      <dt>Alamat :</dt>
      <dd><?php echo e($siswa->alamat); ?></dd>
      <dt>No. Telp :</dt>
      <dd><?php echo e($siswa->no_telp); ?></dd>
      <dt>Email :</dt>
      <dd><?php echo e($siswa->email); ?></dd>
      <dt>Username :</dt>
      <dd><?php echo e($siswa->username); ?></dd>
      <dt>Nama Bank :</dt>
      <dd><?php echo e($siswa->nama_bank); ?></dd>
      <dt>No. Rekening :</dt>
      <dd><?php echo e($siswa->no_rekening); ?></dd>
    </dl>
    <form action="<?php echo e(url("akses_pembayaran")); ?>" method="post">
      <div class="form-group">
        <input type="hidden" name="nis" value="<?php echo e(session('nis')); ?>">
        <?php echo e(csrf_field()); ?>

        <?php if(isset($siswa->akses_pembayaran)): ?>
          <?php if($siswa->akses_pembayaran): ?>
            <input type="hidden" name="akses_bayar" value="0">
            <button type="submit" class="btn btn-warning btn-block btn-fill">Batalkan akses pembayaran</button>
          <?php else: ?>
            <input type="hidden" name="akses_bayar" value="1">
            <button type="submit" class="btn btn-primary btn-block btn-fill">Izinkan akses pembayaran</button>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </form>
    <?php if(session('level') == 'siswa'): ?>
      <a href="<?php echo e(url("akun")); ?>" class="btn btn-primary btn-block">Update Profil</a>
    <?php endif; ?>
  </div>
</div>
