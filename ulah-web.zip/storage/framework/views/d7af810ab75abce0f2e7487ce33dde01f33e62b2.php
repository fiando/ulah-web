<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('desc','Manajemen Tagihan & Pembayaran Online'); ?>

<?php $__env->startSection('content'); ?>

  <div class="row">
    <div class="col-md-6">
      <div class="card">
        <div class="content">
          <h4 class="title">Tahun Ajaran : <small><?php echo e($tahun_pelajaran->tahun_pelajaran); ?></small></h4>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Tagihan</h4>
        </div>
        <div class="content">
          <?php if($tagihan_count > 0): ?>
            <div class="alert alert-info">
              <span>Ada <?php echo e($tagihan_count); ?> Tagihan Siswa Belum Terbayar</span>
            </div>
          <?php endif; ?>
          <ul class="list-unstyled">
            <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><b><?php echo e(date("d-m-Y", strtotime($v->tgl_tagihan))); ?></b> - NIS <?php echo e($v->nis); ?> - <i><?php echo e($v->nama_pembayaran); ?></i> - Rp<?php echo e(number_format($v->nominal,0,'','.')); ?><li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <a href="<?php echo e(url("admin/tagihan")); ?>" class="btn btn-primary btn-block">Periksa Semua Tagihan</a>
        </div>
      </div>
      <div class="card">
        <div class="header">
          <h4 class="title">Transaksi Pembayaran Terbaru</h4>
        </div>
        <div class="content">
          <ul class="list-unstyled">
            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><b><?php echo e(date("d-m-Y", strtotime($v->tgl_bayar))); ?></b> - NIS <?php echo e($v->nis); ?> - <i><?php echo e($v->nama_pembayaran); ?></i> - Rp<?php echo e(number_format($v->nominal,0,'','.')); ?><li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <a href="<?php echo e(url("admin/pembayaran")); ?>" class="btn btn-info btn-block">Periksa Semua Pembayaran</a>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card">
        <div class="header">
          <h4 class="title">Profil Sekolah</h4>
        </div>
        <div class="content">
          <dl class="dl-horizontal">
            <dt>ID Sekolah :</dt>
            <dd><?php echo e($sekolah->ididentitas_sekolah); ?></dd>
            <dt>Nama Sekolah :</dt>
            <dd><?php echo e($sekolah->nama); ?></dd>
            <dt>Status Sekolah :</dt>
            <dd><?php echo e($sekolah->status); ?></dd>
            <dt>Bentuk Pendidikan :</dt>
            <dd><?php echo e($sekolah->bentuk_pendidikan); ?></dd>
            <dt>Akreditasi :</dt>
            <dd><?php echo e($sekolah->akreditasi); ?></dd>
            <dt>Kurikulum :</dt>
            <dd><?php echo e($sekolah->kurikulum); ?></dd>
            <dt>Kepala Sekolah : </dt>
            <dd><?php echo e($sekolah->kepala_sekolah); ?></dd>
            <dt>Alamat :</dt>
            <dd><?php echo e($sekolah->alamat); ?></dd>
            <dt>Email :</dt>
            <dd><?php echo e($sekolah->email); ?></dd>
            <dt>No. Telepon : </dt>
            <dd><?php echo e($sekolah->no_telp); ?></dd>
            <dt>Rekening : </dt>
            <dd><?php echo e($sekolah->rekening); ?> ( <?php echo e($sekolah->nama_bank); ?> )</dd>
            <dt>Website : </dt>
            <dd><?php echo e($sekolah->website); ?></dd>
          </dl>
          <a href="<?php echo e(url("identitas-sekolah")); ?>" class="btn btn-default btn-block">Update Profil Sekolah</a>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>