<?php $__env->startSection('title','Histori Pembayaran'); ?>
<?php $__env->startSection('desc','Informasi Pembayaran Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="content">
          <table class="table">
             <thead>
               <tr>
                 <th>#</th>
                 <th>Jenis Pembayaran</th>
                 <th>Tanggal Tagihan</th>
                 <th>Tanggal Pembayaran</th>
                 <th>Status</th>
                 <th>Tahun Ajaran</th>
               </tr>
             </thead>
             <tbody>
               <tr>
                 <td>Pembayaran SPP</td>
                 <td>250000</td>
                 <td>01-10-2018</td>
                 <td>01-10-2018</td>
                 <td>Lunas</td>
                 <td>2017/2018</td>
               </tr>
             </tbody>
           </table>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="well">
        <div class="header">
          <h4 class="title">Filter</h4>
        </div>
        <div class="content">
          <form class="form-horizontal">
            <div class="form-group">
              <label class="col-sm-4 control-label">Tahun Ajaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="tahun_ajaran">
                  <option value="">Semua</option>
                  <option value="">2017/2018</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-4 control-label">Jenis Pembayaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="jenis_pembayaran">
                  <option value="">Semua</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-4 col-sm-8">
                <button type="submit" class="btn btn-info btn-block btn-fill">Filter</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="well">
        <h5><b>Total Pembayaran Bulan Ini</b></h5>
        <p>Rp. 250.000 ( 1 x Transaksi )</p>
        <h5><b>Banyaknya Transaksi</b></h5>
        <p>5 Kali</p>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>