<?php $__env->startSection('title','Detail Bank'); ?>
<?php $__env->startSection('desc','Melihat Detail Data Bank'); ?>

<?php $__env->startSection('content'); ?>


  <div class="card">
  <div class="content">
    <h5><p class="category">ID</p><?php echo e($bank->kode); ?></h5>
    <h5><p class="category">Nama</p><?php echo e($bank->nama); ?></h5>

    <form class="" action="<?php echo e(url("admin/bank/{$bank->kode}")); ?>" method="post">
      <a class="btn btn-fill btn-info" href="<?php echo e(url("admin/bank/{$bank->kode}")); ?>/edit">Edit</a>
      <button class="btn btn-fill btn-danger" type="submit" name="delete" onClick="return confirm('Anda yakin ingin menghapus ?')">Delete</button>
      <?php echo e(method_field('DELETE')); ?>

      <?php echo e(csrf_field()); ?>

    </form>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>