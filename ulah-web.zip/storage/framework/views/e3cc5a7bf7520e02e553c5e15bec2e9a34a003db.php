
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="card">
        <div class="header text-center">
          <h4 class="title">Identitas Sekolah</h4>
          <p class="category">Informasi Mengenai Sekolah</p>
          <br>
        </div>
        <div class="content">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <dl class="dl-horizontal">
                <dt>ID Sekolah :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Nama Sekolah :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Status Sekolah :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Bentuk Pendidikan :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Akreditasi :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Kurikulum :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Kepala Sekolah : </dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Alamat :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Email :</dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>No. Telepon : </dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Rekening : </dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
                <dt>Website : </dt>
                <dd>Lorem ipsum dolor sit amet.</dd>
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
