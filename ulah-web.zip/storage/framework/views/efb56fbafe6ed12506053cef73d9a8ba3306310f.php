<?php $__env->startSection('title','Histori Pembayaran'); ?>
<?php $__env->startSection('desc','Informasi Pembayaran Siswa'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-8">
      <div class="card">
        <div class="content">
          <table class="table" id="pembayaran">
             <thead>
               <tr>
                 <th>Jenis Pembayaran</th>
                 <th>Nominal</th>
                 <th>Tgl Tagihan</th>
                 <th>Tgl Bayar</th>
                 <th>Tahun Ajaran</th>
               </tr>
             </thead>
             <tbody>
               <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   <td><?php echo e($v->nama_pembayaran); ?></td>
                   <td><?php echo e($v->nominal); ?></td>
                   <td><?php echo e($v->tgl_tagihan); ?></td>
                   <td><?php echo e($v->tgl_bayar); ?></td>
                   <td><?php echo e($v->tahun_pelajaran); ?></td>
                 </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
           </table>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="well">
        <div class="header">
          <h4 class="title">Filter</h4>
        </div>
        <div class="content">
          <form class="form-horizontal">
            <div class="form-group">
              <label class="col-sm-4 control-label">Tahun Ajaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="tahun_ajaran">
                  <option value="">Semua</option>
                  <option value="">2017/2018</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-4 control-label">Jenis Pembayaran</label>
              <div class="col-sm-8">
                <select class="form-control" name="jenis_pembayaran">
                  <option value="">Semua</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-4 col-sm-8">
                <button type="button" class="disabled btn btn-info btn-block btn-fill">Filter</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      <div class="well">
        <h5><b>Total Transaksi</b></h5>
        <p>Rp<?php echo e(number_format($total_transaksi,0,'','.')); ?></p>
        <h5><b>Banyaknya Transaksi</b></h5>
        <p><?php echo e($pembayaran_count); ?> Kali</p>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  ##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
  <script type="text/javascript">
  $(document).ready( function () {
    $('#pembayaran').DataTable( {
      "order": [[ 3, "desc" ]]
  });
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>