<!DOCTYPE html>
<html lang="en">
<head>
	<title>ULAH LOGIN</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="<?php echo e(url("img/logo.png")); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url("/login/vendor/bootstrap/css/bootstrap.min.css")); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url("/login/css/util.css")); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url("/login/css/main.css")); ?>">
</head>
<body>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form" method="post" action="<?php echo e(url("masuk")); ?>">
					<span class="login100-form-title p-b-33">
						Login Akun
					</span>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="email" placeholder="Username">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn">
							Sign in
						</button>
					</div>

					<div class="text-center p-t-45 p-b-4">
						<span class="txt1">
							Forgot
						</span>

						<a href="#" class="txt2 hov1">
							Username / Password?
						</a>
					</div>

					<div class="text-center">
						<span class="txt1">
							Create an account?
						</span>

						<a href="#" class="txt2 hov1">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>
