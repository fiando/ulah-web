<?php $__env->startSection('title','Pembayaran Tagihan Siswa'); ?>
<?php $__env->startSection('desc','Pilih metode pembayaran untuk melakukan pembayaran'); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="card">
        <div class="content">
          <div class="form-group">
            <h4 class="text-left">Tagihan Tanggal <b><i><?php echo e(date("d-m-Y", strtotime($tagihan->tgl_tagihan))); ?></i></b></h4>
            <h4 class="text-left">Pembayaran <b><?php echo e($tagihan->nama_pembayaran); ?></b></h4>
            <h4>Nominal : <b>Rp<?php echo e(number_format($tagihan->nominal,0,0,'.')); ?></b></h4>
            <hr>
            <h4>Metode Pembayaran</h4>
            <form action="<?php echo e(url('pembayaran_tagihan/finpay')); ?>" method="post">
              <select class="form-control" name="metode_bayar">
                <option value="trf">Transfer</option>
                <option value="cc">Credit Card</option>
              </select>
              <br>
              <div class="row">
                <div class="col-md-12">
                  <div class="thumbnail">
                    <img class="img-responsive" src="<?php echo e(asset('img/finpay.jpg')); ?>" alt="...">
                    <div class="caption">
                      <input type="hidden" name="id_tagihan" value="<?php echo e($tagihan->idpembayaran); ?>">
                      <input type="hidden" name="nama" value="<?php echo e($tagihan->nama); ?>">
                      <input type="hidden" name="nis" value="<?php echo e($tagihan->nis); ?>">
                      <input type="hidden" name="nomor" value="<?php echo e($tagihan->no_telp); ?>">
                      <input type="hidden" name="nama_pembayaran" value="<?php echo e($tagihan->nama_pembayaran); ?>">
                      <input type="hidden" name="nominal" value="<?php echo e($tagihan->nominal); ?>">
                      <input type="hidden" name="tgl_tagihan" value="<?php echo e($tagihan->tgl_tagihan); ?>">
                      <button type="submit" name="bayar" class="btn btn-primary btn-block">Lanjutkan</button>
                      <?php echo e(csrf_field()); ?>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>